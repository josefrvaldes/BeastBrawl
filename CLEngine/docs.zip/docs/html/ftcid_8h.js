var ftcid_8h =
[
    [ "FT_Get_CID_From_Glyph_Index", "ftcid_8h.html#adf755d4e91c6ecac8bd637f52ae3b8ef", null ],
    [ "FT_Get_CID_Is_Internally_CID_Keyed", "ftcid_8h.html#a87e51d0237b4f8f1f505efaf7e5721f1", null ],
    [ "FT_Get_CID_Registry_Ordering_Supplement", "ftcid_8h.html#a4d090c134b19ca4528a4dd09094630f3", null ]
];