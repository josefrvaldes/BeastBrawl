var color4_8inl =
[
    [ "AI_COLOR4D_INL_INC", "color4_8inl.html#a77423de67c2c45745a4a79741ad8a4b1", null ]
];