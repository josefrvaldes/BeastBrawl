var annotated_dup =
[
    [ "CLE", "namespace_c_l_e.html", "namespace_c_l_e" ],
    [ "Material", "struct_material.html", "struct_material" ],
    [ "Mesh", "class_mesh.html", "class_mesh" ],
    [ "Texture", "struct_texture.html", "struct_texture" ],
    [ "Vertex", "struct_vertex.html", "struct_vertex" ]
];