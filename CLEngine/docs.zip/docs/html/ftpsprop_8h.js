var ftpsprop_8h =
[
    [ "ps_property_get", "ftpsprop_8h.html#acc44d0adbe688e96fb38d09699a49e0d", null ],
    [ "ps_property_set", "ftpsprop_8h.html#a76fbd1d114b96084a63e9c9a13dafe1e", null ]
];