var ftlcdfil_8h =
[
    [ "FT_LCD_FILTER_FIVE_TAPS", "ftlcdfil_8h.html#a7c6ed9b6c4e9a1efd92ef16c987bea89", null ],
    [ "FT_LcdFilter", "ftlcdfil_8h.html#aa063aecb411a78f6a7b603d94aab4102", null ],
    [ "FT_LcdFiveTapFilter", "ftlcdfil_8h.html#aad84df0eb14f9896e340ea965328fead", null ],
    [ "FT_LcdFilter_", "ftlcdfil_8h.html#a050b6cfffcf53795587eb8eae7147577", [
      [ "FT_LCD_FILTER_NONE", "ftlcdfil_8h.html#a050b6cfffcf53795587eb8eae7147577ae6fa91add012c5bf6d570188e5b239c4", null ],
      [ "FT_LCD_FILTER_DEFAULT", "ftlcdfil_8h.html#a050b6cfffcf53795587eb8eae7147577ab606094a9ccac39d5431519a6c4055e3", null ],
      [ "FT_LCD_FILTER_LIGHT", "ftlcdfil_8h.html#a050b6cfffcf53795587eb8eae7147577a104fce3f715c045ad3b11f0155abe2b9", null ],
      [ "FT_LCD_FILTER_LEGACY1", "ftlcdfil_8h.html#a050b6cfffcf53795587eb8eae7147577a146b1e510ec55ea1037aa4f66bada7cc", null ],
      [ "FT_LCD_FILTER_LEGACY", "ftlcdfil_8h.html#a050b6cfffcf53795587eb8eae7147577aace329ea0f5d6bcbf45f6b77a038b492", null ],
      [ "FT_LCD_FILTER_MAX", "ftlcdfil_8h.html#a050b6cfffcf53795587eb8eae7147577a8130ccb414d2e49441cadedf857b2704", null ]
    ] ],
    [ "FT_Library_SetLcdFilter", "ftlcdfil_8h.html#a230881dc8a783c68ef48fec0bdf37f7a", null ],
    [ "FT_Library_SetLcdFilterWeights", "ftlcdfil_8h.html#a8400fa1c5a65e92e71de810d48ee646f", null ],
    [ "FT_Library_SetLcdGeometry", "ftlcdfil_8h.html#a3a0ea9b4aa9069c36c87fc65fc0308a2", null ]
];