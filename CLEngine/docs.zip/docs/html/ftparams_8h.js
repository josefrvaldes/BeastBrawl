var ftparams_8h =
[
    [ "FT_PARAM_TAG_IGNORE_PREFERRED_FAMILY", "ftparams_8h.html#aab315ae5a6844245f5c9ae058845c33f", null ],
    [ "FT_PARAM_TAG_IGNORE_PREFERRED_SUBFAMILY", "ftparams_8h.html#ac8e316e27901724b0a8b4d7f6a10d5e2", null ],
    [ "FT_PARAM_TAG_IGNORE_TYPOGRAPHIC_FAMILY", "ftparams_8h.html#a0fb876ff06cb4eee02bc1ef6e5058bf2", null ],
    [ "FT_PARAM_TAG_IGNORE_TYPOGRAPHIC_SUBFAMILY", "ftparams_8h.html#a79b17fd30d6f6c020620a7518184777e", null ],
    [ "FT_PARAM_TAG_INCREMENTAL", "ftparams_8h.html#a3d6a330a57d3d52a7ca4a404c83e40ba", null ],
    [ "FT_PARAM_TAG_LCD_FILTER_WEIGHTS", "ftparams_8h.html#a8a33b5276ab5d6d0fe569b11b6bdb870", null ],
    [ "FT_PARAM_TAG_RANDOM_SEED", "ftparams_8h.html#a470026201bbaf5f9a69d0e7768c386d3", null ],
    [ "FT_PARAM_TAG_STEM_DARKENING", "ftparams_8h.html#ac9399998540ae835940d91fb852ba363", null ],
    [ "FT_PARAM_TAG_UNPATENTED_HINTING", "ftparams_8h.html#a09b6a132d9ca1c73813266846e8db835", null ]
];