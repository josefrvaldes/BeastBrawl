var ftvalid_8h =
[
    [ "FT_ValidatorRec_", "struct_f_t___validator_rec__.html", "struct_f_t___validator_rec__" ],
    [ "FT_INVALID", "ftvalid_8h.html#ad1358a375d266e0a6dd181893ee2a3e1", null ],
    [ "FT_INVALID_", "ftvalid_8h.html#a9c710d862d3c268716ca7820311947cd", null ],
    [ "FT_INVALID_DATA", "ftvalid_8h.html#a7e340a7116b04fc9886b71546eae01ee", null ],
    [ "FT_INVALID_FORMAT", "ftvalid_8h.html#a06c85535de052f8c39ebd0ea1300963b", null ],
    [ "FT_INVALID_GLYPH_ID", "ftvalid_8h.html#af3ebe7b7531c78d4956aefb53770fb6a", null ],
    [ "FT_INVALID_OFFSET", "ftvalid_8h.html#a38c505c642e727b7844a9354982f9af6", null ],
    [ "FT_INVALID_TOO_SHORT", "ftvalid_8h.html#a34566b84985b7492dfd7f7db469d80ac", null ],
    [ "FT_VALIDATOR", "ftvalid_8h.html#a56d5a1e2ae4a667ebe110110fa7aba64", null ],
    [ "FT_ValidationLevel", "ftvalid_8h.html#a888f61b9e1821a9a378a6356816de23f", null ],
    [ "FT_Validator", "ftvalid_8h.html#ab9ceda164f3e9d44345b2199b1d7838a", null ],
    [ "FT_ValidatorRec", "ftvalid_8h.html#a90f2e8d0e69af68e0bbf38d62e323aab", null ],
    [ "FT_ValidationLevel_", "ftvalid_8h.html#a11d28f35cb7beadb9b6aa446fcb21eb6", [
      [ "FT_VALIDATE_DEFAULT", "ftvalid_8h.html#a11d28f35cb7beadb9b6aa446fcb21eb6ae01a56fc32ebfb4c1816339bc8868df0", null ],
      [ "FT_VALIDATE_TIGHT", "ftvalid_8h.html#a11d28f35cb7beadb9b6aa446fcb21eb6ae546ccfdb9a36dac676c0402647f507e", null ],
      [ "FT_VALIDATE_PARANOID", "ftvalid_8h.html#a11d28f35cb7beadb9b6aa446fcb21eb6aeadcdbba0eb4f6466688cfae16973b66", null ]
    ] ],
    [ "ft_validator_error", "ftvalid_8h.html#a9504bbbfc7751a25a39d1330f92655b3", null ],
    [ "ft_validator_init", "ftvalid_8h.html#a6042da97a44e287d5d99b459aae11ea0", null ],
    [ "ft_validator_run", "ftvalid_8h.html#a40b463141ddaf56437d42b1f9b7894ef", null ]
];