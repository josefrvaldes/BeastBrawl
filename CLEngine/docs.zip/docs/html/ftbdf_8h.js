var ftbdf_8h =
[
    [ "BDF_PropertyRec_", "struct_b_d_f___property_rec__.html", "struct_b_d_f___property_rec__" ],
    [ "BDF_Property", "ftbdf_8h.html#a92058ec2fe0c3945ac0412e1ed005e7b", null ],
    [ "BDF_PropertyRec", "ftbdf_8h.html#a288716a8f34789daccf6f4ac8a0a280d", null ],
    [ "BDF_PropertyType", "ftbdf_8h.html#a644d42d440ad33808bc536bd511e68bc", null ],
    [ "BDF_PropertyType_", "ftbdf_8h.html#a1c5af1ece15330758f3698fd6ac8a277", [
      [ "BDF_PROPERTY_TYPE_NONE", "ftbdf_8h.html#a1c5af1ece15330758f3698fd6ac8a277a24660540f9c56b66bead6a2a171b063b", null ],
      [ "BDF_PROPERTY_TYPE_ATOM", "ftbdf_8h.html#a1c5af1ece15330758f3698fd6ac8a277aacbc1df7ea76316d94dc8dc7ec595a2d", null ],
      [ "BDF_PROPERTY_TYPE_INTEGER", "ftbdf_8h.html#a1c5af1ece15330758f3698fd6ac8a277afd64275c8077e54692a10867f5cfef23", null ],
      [ "BDF_PROPERTY_TYPE_CARDINAL", "ftbdf_8h.html#a1c5af1ece15330758f3698fd6ac8a277a09a5f69fee3406203b921f3d830bdc5d", null ]
    ] ],
    [ "FT_Get_BDF_Charset_ID", "ftbdf_8h.html#ae36fcca73dae5110224edb5b60e40c66", null ],
    [ "FT_Get_BDF_Property", "ftbdf_8h.html#a5e6f277df105df5fb42d0f56e582a3e9", null ]
];