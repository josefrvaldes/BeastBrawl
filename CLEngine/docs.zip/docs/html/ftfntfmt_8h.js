var ftfntfmt_8h =
[
    [ "FT_Get_Font_Format", "ftfntfmt_8h.html#a68ce014beeb21bb2e9ce543743f9ec0e", null ],
    [ "FT_Get_X11_Font_Format", "ftfntfmt_8h.html#a582c3c608c05f7999978004c419ead56", null ]
];