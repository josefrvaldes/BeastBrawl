var ftsynth_8h =
[
    [ "FT_GlyphSlot_Embolden", "ftsynth_8h.html#a2048d29fd6e91aa3a237751abaa0c275", null ],
    [ "FT_GlyphSlot_Oblique", "ftsynth_8h.html#abfcd3735cc4000be49eef4deaa1465fb", null ]
];