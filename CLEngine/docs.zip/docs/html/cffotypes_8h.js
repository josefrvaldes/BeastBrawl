var cffotypes_8h =
[
    [ "CFF_SizeRec_", "struct_c_f_f___size_rec__.html", "struct_c_f_f___size_rec__" ],
    [ "CFF_GlyphSlotRec_", "struct_c_f_f___glyph_slot_rec__.html", "struct_c_f_f___glyph_slot_rec__" ],
    [ "CFF_InternalRec_", "struct_c_f_f___internal_rec__.html", "struct_c_f_f___internal_rec__" ],
    [ "CFF_Transform_", "struct_c_f_f___transform__.html", "struct_c_f_f___transform__" ],
    [ "CFF_GlyphSlot", "cffotypes_8h.html#ab0311d60969475c27e1347c46a37eabd", null ],
    [ "CFF_GlyphSlotRec", "cffotypes_8h.html#a517a3e35f89c94be2c7d3ecadf0b4e0d", null ],
    [ "CFF_Internal", "cffotypes_8h.html#ab40d41ef320a6e5c964a3b06f385c766", null ],
    [ "CFF_InternalRec", "cffotypes_8h.html#adc2537e65fceca40f34394e1c906f219", null ],
    [ "CFF_Size", "cffotypes_8h.html#ac831d1b4f969ac28fd625dd7b668bb44", null ],
    [ "CFF_SizeRec", "cffotypes_8h.html#a0a3cb5a715d6a41a5c3304eb05fe0957", null ],
    [ "CFF_Transform", "cffotypes_8h.html#a3981437db83eecbf1b33e7fc1f1e40c9", null ],
    [ "CFF_Face", "cffotypes_8h.html#aa4f069f85aa88afe0f74a74dea2218b1", null ]
];