var cfileio_8h =
[
    [ "aiFileIO", "structai_file_i_o.html", "structai_file_i_o" ],
    [ "aiFile", "structai_file.html", "structai_file" ],
    [ "AI_FILEIO_H_INC", "cfileio_8h.html#ae0c842cece18608e0566cbe270c97d2e", null ],
    [ "aiFileCloseProc", "cfileio_8h.html#ab6e7f26b63f2d1ed9655e97bd4ebd38c", null ],
    [ "aiFileFlushProc", "cfileio_8h.html#a49a7a4a25167c7aa03dfe80ae5bdd959", null ],
    [ "aiFileOpenProc", "cfileio_8h.html#ad61b536884b9b6b7e8673edb5539d37c", null ],
    [ "aiFileReadProc", "cfileio_8h.html#a482e6ebea846d515ef23556d0f1717f4", null ],
    [ "aiFileSeek", "cfileio_8h.html#a9d44e516b1ce6ef3da4295045d6ec217", null ],
    [ "aiFileTellProc", "cfileio_8h.html#a30d575ddf8f46426ecb12c95f92b1686", null ],
    [ "aiFileWriteProc", "cfileio_8h.html#a21d0825136cd8be942613ff77479045d", null ],
    [ "aiUserData", "cfileio_8h.html#a176132d0cd51c96302089ff3f8a8ee1c", null ]
];