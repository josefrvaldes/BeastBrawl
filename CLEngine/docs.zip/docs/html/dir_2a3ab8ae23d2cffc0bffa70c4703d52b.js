var dir_2a3ab8ae23d2cffc0bffa70c4703d52b =
[
    [ "Compiler", "dir_0ffc07ad43e5d83174e0a5b32fd5959e.html", "dir_0ffc07ad43e5d83174e0a5b32fd5959e" ],
    [ "ai_assert.h", "ai__assert_8h.html", "ai__assert_8h" ],
    [ "anim.h", "anim_8h.html", "anim_8h" ],
    [ "camera.h", "camera_8h.html", "camera_8h" ],
    [ "cexport.h", "cexport_8h.html", "cexport_8h" ],
    [ "cfileio.h", "cfileio_8h.html", "cfileio_8h" ],
    [ "cimport.h", "cimport_8h.html", "cimport_8h" ],
    [ "color4.h", "color4_8h.html", "color4_8h" ],
    [ "color4.inl", "color4_8inl.html", "color4_8inl" ],
    [ "config.h", "config_8h.html", "config_8h" ],
    [ "DefaultIOStream.h", "_default_i_o_stream_8h.html", [
      [ "DefaultIOStream", "class_assimp_1_1_default_i_o_stream.html", "class_assimp_1_1_default_i_o_stream" ]
    ] ],
    [ "DefaultIOSystem.h", "_default_i_o_system_8h.html", [
      [ "DefaultIOSystem", "class_assimp_1_1_default_i_o_system.html", "class_assimp_1_1_default_i_o_system" ]
    ] ],
    [ "DefaultLogger.hpp", "_default_logger_8hpp.html", "_default_logger_8hpp" ],
    [ "Defines.h", "_defines_8h.html", "_defines_8h" ],
    [ "defs.h", "defs_8h.html", "defs_8h" ],
    [ "Exporter.hpp", "_exporter_8hpp.html", "_exporter_8hpp" ],
    [ "Importer.hpp", "_importer_8hpp.html", "_importer_8hpp" ],
    [ "importerdesc.h", "importerdesc_8h.html", "importerdesc_8h" ],
    [ "IOStream.hpp", "_i_o_stream_8hpp.html", "_i_o_stream_8hpp" ],
    [ "IOSystem.hpp", "_i_o_system_8hpp.html", "_i_o_system_8hpp" ],
    [ "light.h", "light_8h.html", "light_8h" ],
    [ "Logger.hpp", "_logger_8hpp.html", "_logger_8hpp" ],
    [ "LogStream.hpp", "_log_stream_8hpp.html", [
      [ "LogStream", "class_assimp_1_1_log_stream.html", "class_assimp_1_1_log_stream" ]
    ] ],
    [ "material.h", "material_8h.html", "material_8h" ],
    [ "material.inl", "material_8inl.html", "material_8inl" ],
    [ "matrix3x3.h", "matrix3x3_8h.html", "matrix3x3_8h" ],
    [ "matrix3x3.inl", "matrix3x3_8inl.html", "matrix3x3_8inl" ],
    [ "matrix4x4.h", "matrix4x4_8h.html", "matrix4x4_8h" ],
    [ "matrix4x4.inl", "matrix4x4_8inl.html", "matrix4x4_8inl" ],
    [ "mesh.h", "mesh_8h.html", "mesh_8h" ],
    [ "metadata.h", "metadata_8h.html", "metadata_8h" ],
    [ "NullLogger.hpp", "_null_logger_8hpp.html", [
      [ "NullLogger", "class_assimp_1_1_null_logger.html", "class_assimp_1_1_null_logger" ]
    ] ],
    [ "postprocess.h", "postprocess_8h.html", "postprocess_8h" ],
    [ "ProgressHandler.hpp", "_progress_handler_8hpp.html", "_progress_handler_8hpp" ],
    [ "quaternion.h", "quaternion_8h.html", "quaternion_8h" ],
    [ "quaternion.inl", "quaternion_8inl.html", "quaternion_8inl" ],
    [ "scene.h", "scene_8h.html", "scene_8h" ],
    [ "SceneCombiner.h", "_scene_combiner_8h.html", "_scene_combiner_8h" ],
    [ "texture.h", "texture_8h.html", "texture_8h" ],
    [ "types.h", "types_8h.html", "types_8h" ],
    [ "vector2.h", "vector2_8h.html", "vector2_8h" ],
    [ "vector2.inl", "vector2_8inl.html", "vector2_8inl" ],
    [ "vector3.h", "vector3_8h.html", "vector3_8h" ],
    [ "vector3.inl", "vector3_8inl.html", "vector3_8inl" ],
    [ "version.h", "version_8h.html", "version_8h" ]
];