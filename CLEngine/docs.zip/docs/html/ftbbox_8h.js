var ftbbox_8h =
[
    [ "FT_Outline_Get_BBox", "ftbbox_8h.html#ae720b963244ae704e1aa60aed4eecac7", null ]
];