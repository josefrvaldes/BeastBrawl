var ftcolor_8h =
[
    [ "FT_Color_", "struct_f_t___color__.html", "struct_f_t___color__" ],
    [ "FT_Palette_Data_", "struct_f_t___palette___data__.html", "struct_f_t___palette___data__" ],
    [ "FT_PALETTE_FOR_DARK_BACKGROUND", "ftcolor_8h.html#a088cc90cb974acc0bedfe30d4f450a29", null ],
    [ "FT_PALETTE_FOR_LIGHT_BACKGROUND", "ftcolor_8h.html#a4359656c3c0507a5529fc633ee641ce1", null ],
    [ "FT_Color", "ftcolor_8h.html#a2dfafc33e5e9d6af4961a0e9c687e250", null ],
    [ "FT_Palette_Data", "ftcolor_8h.html#ab2bc294e65e6251d8a3581be7342cd59", null ],
    [ "FT_Palette_Data_Get", "ftcolor_8h.html#a64cac166a372c0980c75eb94df41718e", null ],
    [ "FT_Palette_Select", "ftcolor_8h.html#ac744666049785758585c03bcbd349138", null ],
    [ "FT_Palette_Set_Foreground_Color", "ftcolor_8h.html#a87b5df5969998129860bda8e2c9e3de8", null ]
];