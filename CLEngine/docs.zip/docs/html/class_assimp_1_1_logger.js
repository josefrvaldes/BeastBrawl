var class_assimp_1_1_logger =
[
    [ "ErrorSeverity", "class_assimp_1_1_logger.html#acd0b52a87d6fc11e957ed2c6e2ad75b6", [
      [ "Debugging", "class_assimp_1_1_logger.html#acd0b52a87d6fc11e957ed2c6e2ad75b6a0cb475014d27098c3423738c571d857f", null ],
      [ "Info", "class_assimp_1_1_logger.html#acd0b52a87d6fc11e957ed2c6e2ad75b6aa3377a574928b86f7de55c5df154f461", null ],
      [ "Warn", "class_assimp_1_1_logger.html#acd0b52a87d6fc11e957ed2c6e2ad75b6a1279c77aaee5a3d7df835a9b9305a697", null ],
      [ "Err", "class_assimp_1_1_logger.html#acd0b52a87d6fc11e957ed2c6e2ad75b6a71054d0b1323abcea46d050d69013d27", null ]
    ] ],
    [ "LogSeverity", "class_assimp_1_1_logger.html#a8b6248a0fd062431e8572556350d29e6", [
      [ "NORMAL", "class_assimp_1_1_logger.html#a8b6248a0fd062431e8572556350d29e6a79d16f85dc21486ee489f300027e8eda", null ],
      [ "VERBOSE", "class_assimp_1_1_logger.html#a8b6248a0fd062431e8572556350d29e6afc9d1d86aa82fdb80e00c99b3c1ce486", null ]
    ] ],
    [ "~Logger", "class_assimp_1_1_logger.html#a27dd2bd4fd3b9cde0635ed22aad687c3", null ],
    [ "Logger", "class_assimp_1_1_logger.html#a784e6d1a741072b17bab32a6a41055e8", null ],
    [ "Logger", "class_assimp_1_1_logger.html#accc0ffea63ddf0982d8c2ba7e07f0716", null ],
    [ "attachStream", "class_assimp_1_1_logger.html#aaf32a42b02a7e227076013d01e349871", null ],
    [ "debug", "class_assimp_1_1_logger.html#a3b10454ab4c0949f251062376d9c4161", null ],
    [ "debug", "class_assimp_1_1_logger.html#af978b5a592fef74ec3b5634ebdf22a3b", null ],
    [ "detatchStream", "class_assimp_1_1_logger.html#a9489263727f29fecbd705d5c8d2590c0", null ],
    [ "error", "class_assimp_1_1_logger.html#aa8b7c3f56dc4cecfdacc8bb36ba3fac1", null ],
    [ "error", "class_assimp_1_1_logger.html#a42b564d43664bb9fdc72613aa3e54770", null ],
    [ "getLogSeverity", "class_assimp_1_1_logger.html#a4b565acf3a82915c35bb18e2a85ab43d", null ],
    [ "info", "class_assimp_1_1_logger.html#a12b8a125083c47ac0bb6056f00761e52", null ],
    [ "info", "class_assimp_1_1_logger.html#a6774f0cc4373195ef899799a40ad9879", null ],
    [ "OnDebug", "class_assimp_1_1_logger.html#aded6996d20f14204877097b88bd5eac6", null ],
    [ "OnError", "class_assimp_1_1_logger.html#ae2ea0790aba6125b90af0f2768b0759d", null ],
    [ "OnInfo", "class_assimp_1_1_logger.html#aba81c4562ff8db83f06c6b62f2eb7983", null ],
    [ "OnWarn", "class_assimp_1_1_logger.html#ab8066978dd37992f711d75d49cf4607b", null ],
    [ "setLogSeverity", "class_assimp_1_1_logger.html#a8fb4fa4c2c329a36ac39bc9c743925f1", null ],
    [ "warn", "class_assimp_1_1_logger.html#a32bc5ee4b23df13551b83b925907f1b1", null ],
    [ "warn", "class_assimp_1_1_logger.html#afe0f9914014c7a62780a67557b9fc0d3", null ],
    [ "m_Severity", "class_assimp_1_1_logger.html#ae1c96711eb927a5b33745a6211e93f56", null ]
];