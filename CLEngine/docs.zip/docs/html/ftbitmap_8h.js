var ftbitmap_8h =
[
    [ "FT_Bitmap_Blend", "ftbitmap_8h.html#a26fedb4ff5f98f976860e790b9eb8042", null ],
    [ "FT_Bitmap_Convert", "ftbitmap_8h.html#a68913634b7221aa1eafddeeff7c19f27", null ],
    [ "FT_Bitmap_Copy", "ftbitmap_8h.html#aa139914a4cf59cdb61ee4675f11ee940", null ],
    [ "FT_Bitmap_Done", "ftbitmap_8h.html#a78eb7860bae966f76888ebd2a1b59c66", null ],
    [ "FT_Bitmap_Embolden", "ftbitmap_8h.html#a90f7fa52ce51528e0beb9433d4cd4a96", null ],
    [ "FT_Bitmap_Init", "ftbitmap_8h.html#a68a158b1f9ee1d4e5518f1d0955e8028", null ],
    [ "FT_Bitmap_New", "ftbitmap_8h.html#a6ad90fc58c747f5e0319fa5d8b64e715", null ],
    [ "FT_GlyphSlot_Own_Bitmap", "ftbitmap_8h.html#a0cd7dead9518404759c2d061d90d9fde", null ]
];