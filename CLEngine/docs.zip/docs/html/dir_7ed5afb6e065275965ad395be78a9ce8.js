var dir_7ed5afb6e065275965ad395be78a9ce8 =
[
    [ "CLColor.cpp", "_c_l_color_8cpp.html", null ],
    [ "CLColor.h", "_c_l_color_8h.html", [
      [ "CLColor", "class_c_l_e_1_1_c_l_color.html", "class_c_l_e_1_1_c_l_color" ]
    ] ]
];