var ftadvanc_8h =
[
    [ "FT_ADVANCE_FLAG_FAST_ONLY", "ftadvanc_8h.html#a255df735f7d68137eda06420b9a5284f", null ],
    [ "FT_Get_Advance", "ftadvanc_8h.html#aef8ae21834ee1e297e542f8d64ab8e4a", null ],
    [ "FT_Get_Advances", "ftadvanc_8h.html#a2d220866cf2b364190c80e7af244f81f", null ]
];