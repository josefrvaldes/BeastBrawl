var class_assimp_1_1_default_logger =
[
    [ "attachStream", "class_assimp_1_1_default_logger.html#abc0ca7a337f8c3e38eca0eb45bb1ccf0", null ],
    [ "detatchStream", "class_assimp_1_1_default_logger.html#a2615f1d1624f1d742d0cf2dd4a5cccc8", null ]
];