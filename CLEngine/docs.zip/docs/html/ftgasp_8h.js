var ftgasp_8h =
[
    [ "FT_GASP_DO_GRAY", "ftgasp_8h.html#a2995ae457255e6a1894ecc071faf7cf7", null ],
    [ "FT_GASP_DO_GRIDFIT", "ftgasp_8h.html#a8e7a3101a625572ad43175a314342949", null ],
    [ "FT_GASP_NO_TABLE", "ftgasp_8h.html#abcadc3eaf5070af9900d3de0776aefc5", null ],
    [ "FT_GASP_SYMMETRIC_GRIDFIT", "ftgasp_8h.html#a02ce7ae0fd49143d4360aa6b934a6809", null ],
    [ "FT_GASP_SYMMETRIC_SMOOTHING", "ftgasp_8h.html#ab6d04b5dc29a54be8effc0cf1116d418", null ],
    [ "FT_Get_Gasp", "ftgasp_8h.html#aa0a4e0d64db79994299e61193521dadb", null ]
];