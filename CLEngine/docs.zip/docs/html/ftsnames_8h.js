var ftsnames_8h =
[
    [ "FT_SfntName_", "struct_f_t___sfnt_name__.html", "struct_f_t___sfnt_name__" ],
    [ "FT_SfntLangTag_", "struct_f_t___sfnt_lang_tag__.html", "struct_f_t___sfnt_lang_tag__" ],
    [ "FT_SfntLangTag", "ftsnames_8h.html#a8e4b3f5b43001f26a849eeb4d8bc156c", null ],
    [ "FT_SfntName", "ftsnames_8h.html#ab114c00b7f2b1944b01bdca9375cc5d0", null ],
    [ "FT_Get_Sfnt_LangTag", "ftsnames_8h.html#ae4b917c2171e3eb3ea0791f33a88b203", null ],
    [ "FT_Get_Sfnt_Name", "ftsnames_8h.html#ad6d1af5af193d6f42b76f733d924eed7", null ],
    [ "FT_Get_Sfnt_Name_Count", "ftsnames_8h.html#a3ef7496741da58eadb90d455649f5eda", null ]
];