var ftpfr_8h =
[
    [ "FT_Get_PFR_Advance", "ftpfr_8h.html#a9c49a256d7ab3a0f4505be4dc16880d0", null ],
    [ "FT_Get_PFR_Kerning", "ftpfr_8h.html#aa022225c25d3bf1d154d889c3348a095", null ],
    [ "FT_Get_PFR_Metrics", "ftpfr_8h.html#ab96f0dc5133f7ebee84caebb42e277f0", null ]
];