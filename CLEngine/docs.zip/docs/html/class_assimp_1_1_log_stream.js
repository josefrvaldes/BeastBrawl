var class_assimp_1_1_log_stream =
[
    [ "LogStream", "class_assimp_1_1_log_stream.html#ac6863075fc4a6fcffd76ad6af80c18bc", null ],
    [ "~LogStream", "class_assimp_1_1_log_stream.html#a2cf7080efeb4999a02689f2a31843da2", null ],
    [ "write", "class_assimp_1_1_log_stream.html#ab0bfcb5ab9988ef65d7222a50f6e8d37", null ]
];