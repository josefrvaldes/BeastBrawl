var ftotval_8h =
[
    [ "FT_VALIDATE_BASE", "ftotval_8h.html#af8f504482c4d98e4d5076659ca6b5f42", null ],
    [ "FT_VALIDATE_GDEF", "ftotval_8h.html#a99dad4213acfbfa58db4e7edc892a5de", null ],
    [ "FT_VALIDATE_GPOS", "ftotval_8h.html#ad10b42de0c3a5085fe0eaf08c9919abf", null ],
    [ "FT_VALIDATE_GSUB", "ftotval_8h.html#a297baf67df7876358bdb9b55cedcfb40", null ],
    [ "FT_VALIDATE_JSTF", "ftotval_8h.html#aaa9d02651698c57fa78944921330f5e6", null ],
    [ "FT_VALIDATE_MATH", "ftotval_8h.html#a1e92cf0e983fa0ebf89f3a36e31cddcd", null ],
    [ "FT_VALIDATE_OT", "ftotval_8h.html#a757472f13dce76c5522d8a2be8cb5942", null ],
    [ "FT_OpenType_Free", "ftotval_8h.html#a9849378780d43a6723a746c6bfffe0c3", null ],
    [ "FT_OpenType_Validate", "ftotval_8h.html#a61bf2174f1ecc8556949fb3f8356a8df", null ]
];