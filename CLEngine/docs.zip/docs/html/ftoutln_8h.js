var ftoutln_8h =
[
    [ "FT_Orientation", "ftoutln_8h.html#a8ebcc96437212f94a62e2a3318e8fbf6", null ],
    [ "FT_Orientation_", "ftoutln_8h.html#a2dbf6e6c049d366ad388b68fb345bf07", [
      [ "FT_ORIENTATION_TRUETYPE", "ftoutln_8h.html#a2dbf6e6c049d366ad388b68fb345bf07ae280038a0ec1527ec90cb0e9ed00590d", null ],
      [ "FT_ORIENTATION_POSTSCRIPT", "ftoutln_8h.html#a2dbf6e6c049d366ad388b68fb345bf07ac177e0e0925b8f320cfbf516811eb77f", null ],
      [ "FT_ORIENTATION_FILL_RIGHT", "ftoutln_8h.html#a2dbf6e6c049d366ad388b68fb345bf07a027e7d578617eb9a4b46a453e7d657ba", null ],
      [ "FT_ORIENTATION_FILL_LEFT", "ftoutln_8h.html#a2dbf6e6c049d366ad388b68fb345bf07addcd09cc526d8fc58dff146a4baf8d8c", null ],
      [ "FT_ORIENTATION_NONE", "ftoutln_8h.html#a2dbf6e6c049d366ad388b68fb345bf07a26c3be498477ec3c298ca687fe0bb6fc", null ]
    ] ],
    [ "FT_Outline_Check", "ftoutln_8h.html#a163a3f538ff84fb340c799ccfbade5e3", null ],
    [ "FT_Outline_Copy", "ftoutln_8h.html#ae7297822e530e5a1c12eab0aaa5c6adf", null ],
    [ "FT_Outline_Decompose", "ftoutln_8h.html#ad709fe2b765060ec3fcec30113d4afff", null ],
    [ "FT_Outline_Done", "ftoutln_8h.html#add290aad8f9e33e1433d881d522b4f12", null ],
    [ "FT_Outline_Embolden", "ftoutln_8h.html#ac9f3da4e1a733a34323f8cdfeacecd7c", null ],
    [ "FT_Outline_EmboldenXY", "ftoutln_8h.html#a2a74bfce446acc29c9de18a1898eb257", null ],
    [ "FT_Outline_Get_Bitmap", "ftoutln_8h.html#a77905f1b5cb9d52859320deab2a41211", null ],
    [ "FT_Outline_Get_CBox", "ftoutln_8h.html#aee6c38fab9f6f3ec522caaba9e608af7", null ],
    [ "FT_Outline_Get_Orientation", "ftoutln_8h.html#a8e9f53b714835771862aca57d00b89c9", null ],
    [ "FT_Outline_New", "ftoutln_8h.html#a9711c08740dba0e7177acf91c4b4df9c", null ],
    [ "FT_Outline_Render", "ftoutln_8h.html#ae3b0bf0cc293b66aa56846054c3fe9e9", null ],
    [ "FT_Outline_Reverse", "ftoutln_8h.html#a4ee5ae94ee6ac6f9cead139b653ceafd", null ],
    [ "FT_Outline_Transform", "ftoutln_8h.html#ad68e1aa2ec264b97eb1b13f24049e132", null ],
    [ "FT_Outline_Translate", "ftoutln_8h.html#a4f1241539872e9237b7d5c6dcf9183e7", null ]
];