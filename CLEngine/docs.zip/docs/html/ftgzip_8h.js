var ftgzip_8h =
[
    [ "FT_Gzip_Uncompress", "ftgzip_8h.html#a9cbb496aaa7b82a1f2a980f09d6ac68f", null ],
    [ "FT_Stream_OpenGzip", "ftgzip_8h.html#aee3d2329a80956c6233f709caec879d4", null ]
];