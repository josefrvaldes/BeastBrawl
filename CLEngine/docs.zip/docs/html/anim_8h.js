var anim_8h =
[
    [ "aiVectorKey", "structai_vector_key.html", "structai_vector_key" ],
    [ "aiQuatKey", "structai_quat_key.html", "structai_quat_key" ],
    [ "aiMeshKey", "structai_mesh_key.html", "structai_mesh_key" ],
    [ "aiMeshMorphKey", "structai_mesh_morph_key.html", "structai_mesh_morph_key" ],
    [ "aiNodeAnim", "structai_node_anim.html", "structai_node_anim" ],
    [ "aiMeshAnim", "structai_mesh_anim.html", "structai_mesh_anim" ],
    [ "aiMeshMorphAnim", "structai_mesh_morph_anim.html", "structai_mesh_morph_anim" ],
    [ "aiAnimation", "structai_animation.html", "structai_animation" ],
    [ "AI_ANIM_H_INC", "anim_8h.html#afc07ef96362c6baf707f0715739bbbc4", null ],
    [ "aiAnimBehaviour", "anim_8h.html#a201b9e9429b82cd6423ff4a4daf01cef", [
      [ "aiAnimBehaviour_DEFAULT", "anim_8h.html#a201b9e9429b82cd6423ff4a4daf01cefac580185752c298b2e5bca0dbbef7f5c1", null ],
      [ "aiAnimBehaviour_CONSTANT", "anim_8h.html#a201b9e9429b82cd6423ff4a4daf01cefaf6e8fd16ed92f7ec3652c367e15eb798", null ],
      [ "aiAnimBehaviour_LINEAR", "anim_8h.html#a201b9e9429b82cd6423ff4a4daf01cefa735ec243b581565a1ea5c974b07ec260", null ],
      [ "aiAnimBehaviour_REPEAT", "anim_8h.html#a201b9e9429b82cd6423ff4a4daf01cefafa0d6cc9c9718af698b436c7c6da836d", null ],
      [ "_aiAnimBehaviour_Force32Bit", "anim_8h.html#a201b9e9429b82cd6423ff4a4daf01cefa8e18d19abc297d6f6ed86c7a7ab9b4fc", null ]
    ] ]
];