var ftsizes_8h =
[
    [ "FT_Activate_Size", "ftsizes_8h.html#a64b78b9733d559cd38d3db1ad91ae14d", null ],
    [ "FT_Done_Size", "ftsizes_8h.html#a3f370063d752eda02f1a9d54feb863a4", null ],
    [ "FT_New_Size", "ftsizes_8h.html#a8641d59dfb4521af8ff6377bb9b07291", null ]
];