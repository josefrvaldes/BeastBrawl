var ftmac_8h =
[
    [ "FT_DEPRECATED_ATTRIBUTE", "ftmac_8h.html#ab5a769f7628bb6a3c0019f703f9cb549", null ],
    [ "FT_GetFile_From_Mac_ATS_Name", "ftmac_8h.html#a1b20a41fbd72afd847f8c6f74bc70c90", null ],
    [ "FT_GetFile_From_Mac_Name", "ftmac_8h.html#a4630687fc7c0e12e36c88c5a7035659c", null ],
    [ "FT_GetFilePath_From_Mac_ATS_Name", "ftmac_8h.html#a48a9f3a9624dfdf65b36a8c860dca67b", null ],
    [ "FT_New_Face_From_FOND", "ftmac_8h.html#adc5da273e41ace14984ccb6354d0731a", null ],
    [ "FT_New_Face_From_FSRef", "ftmac_8h.html#a9f38fec4cedee7c004e114455dcd0f2a", null ],
    [ "FT_New_Face_From_FSSpec", "ftmac_8h.html#a6f8effcf92ef90fc762ba2908419583b", null ]
];